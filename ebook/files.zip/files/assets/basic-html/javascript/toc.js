﻿
tocList = [
    
      {"tag":"ul", "id" : "TocList","content":[{}
        
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page1.html","text": "Cover"},{"tag":"a", "className": "fontPageNum", "href":"page1.html","text": "1"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page2.html","text": "Preview"},{"tag":"a", "className": "fontPageNum", "href":"page2.html","text": "2"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page3.html","text": "History and Heritage"},{"tag":"a", "className": "fontPageNum", "href":"page3.html","text": "3"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page4.html","text": "The Rooms"},{"tag":"a", "className": "fontPageNum", "href":"page4.html","text": "4"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page7.html","text": "The Bathrooms"},{"tag":"a", "className": "fontPageNum", "href":"page7.html","text": "7"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page8.html","text": "The Lounges"},{"tag":"a", "className": "fontPageNum", "href":"page8.html","text": "8"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page10.html","text": "Courts and Gardens"},{"tag":"a", "className": "fontPageNum", "href":"page10.html","text": "10"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page11.html","text": "Other Facilities"},{"tag":"a", "className": "fontPageNum", "href":"page11.html","text": "11"}]}

    
    
    ,{"tag":"li","content":[{"tag":"a", "className": "fontPageName", "href":"page12.html","text": "Contact"},{"tag":"a", "className": "fontPageNum", "href":"page12.html","text": "12"}]}

    
    
      ]}
    
    ]
  