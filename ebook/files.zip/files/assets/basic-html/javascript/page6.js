﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page6", "num":"6"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1786",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0006.pdf", "size":"276.08 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0006.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"5","src":"page5.html"},
    
    "rightTool":{"innerText":" 7","src":"page7.html"},
    
    "content":[{}
        
    ]
})
 	