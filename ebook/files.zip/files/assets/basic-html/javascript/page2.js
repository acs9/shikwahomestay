﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page2", "num":"2"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0002.pdf", "size":"392.79 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0002.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"1","src":"page1.html"},
    
    "rightTool":{"innerText":" 3","src":"page3.html"},
    
    "content":[{}
        
    ]
})
 	