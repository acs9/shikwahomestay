﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page7", "num":"7"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1786",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0007.pdf", "size":"266.13 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0007.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"6","src":"page6.html"},
    
    "rightTool":{"innerText":" 8","src":"page8.html"},
    
    "content":[{}
        
    ]
})
 	