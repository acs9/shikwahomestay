﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page10", "num":"10"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0010.pdf", "size":"461.90 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0010.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"9","src":"page9.html"},
    
    "rightTool":{"innerText":" 11","src":"page11.html"},
    
    "content":[{}
        
    ]
})
 	