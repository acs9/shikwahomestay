﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page4", "num":"4"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1786",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0004.pdf", "size":"291.62 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0004.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"3","src":"page3.html"},
    
    "rightTool":{"innerText":" 5","src":"page5.html"},
    
    "content":[{}
        
    ]
})
 	