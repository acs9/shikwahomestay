﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page9", "num":"9"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0009.pdf", "size":"374.19 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0009.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"8","src":"page8.html"},
    
    "rightTool":{"innerText":" 10","src":"page10.html"},
    
    "content":[{}
        
    ]
})
 	