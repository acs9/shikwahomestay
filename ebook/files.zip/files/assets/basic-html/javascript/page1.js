﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page1", "num":"1"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2590",
    "width":" 1783",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0001.pdf", "size":"345.52 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0001.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"","src":"toc.html"},
    
    "rightTool":{"innerText":" 2","src":"page2.html"},
    
    "content":[{}
        
    ]
})
 	