﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page3", "num":"3"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1789",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0003.pdf", "size":"426.67 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0003.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"2","src":"page2.html"},
    
    "rightTool":{"innerText":" 4","src":"page4.html"},
    
    "content":[{}
        
    ]
})
 	