﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page11", "num":"11"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0011.pdf", "size":"304.96 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0011.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"10","src":"page10.html"},
    
    "rightTool":{"innerText":" 12","src":"page12.html"},
    
    "content":[{}
        
    ]
})
 	