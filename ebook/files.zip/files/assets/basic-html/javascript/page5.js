﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page5", "num":"5"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0005.pdf", "size":"265.98 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0005.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"4","src":"page4.html"},
    
    "rightTool":{"innerText":" 6","src":"page6.html"},
    
    "content":[{}
        
    ]
})
 	