﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page8", "num":"8"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0008.pdf", "size":"417.89 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0008.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"7","src":"page7.html"},
    
    "rightTool":{"innerText":" 9","src":"page9.html"},
    
    "content":[{}
        
    ]
})
 	