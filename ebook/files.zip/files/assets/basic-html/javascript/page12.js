﻿
    pageContentLoad(
    {
    "currentPage":{"item":"page12", "num":"12"},
    "keywords":"",
    "fullLink":"../../../index.html",
    "height":"2594",
    "width":" 1785",
    "isWide":"False",
    "bookWidth":"1785",
    "bookHeight":"2594",

    "download":[{}
      ,{"pdfPublication":{"url":"../common/downloads/publication.pdf", "size":"4.01 MB"}}
    
      ,{"PdfPage":{"url":"../common/downloads/page0012.pdf", "size":"320.93 KB"}}
     ],

    
    
    "substrate":{"background":"url(../common/page-substrates/page0012.jpg)",
    "backgroundSize":"contain", "backgroundColor":"#FFFFFF"},
    
    "leftTool":{"innerText":"11","src":"page11.html"},
    
    "content":[{}
        
    ]
})
 	